# 目录

* [首页 / 一页速览](README.md)
* [玩家版](player/00-overview.md)
  * [开始上手（Day1–Day3）](player/01-getting-started.md)
  * [挂机 & 宝箱](player/02-idle-and-chest.md)
  * [探索秘境](player/03-explore.md)
  * [神祇（质押挖矿）](player/04-deity-staking.md)
  * [宝石 & 上限](player/05-gems-and-limits.md)
  * [市场与交易指引](player/06-market-guide.md)
  * [FAQ / 术语](player/07-faq.md)
